# testgen/generator.py
from pathlib import Path
from typing import Iterable, Optional, Dict, Any, List
import random

from core.parsers import load_jsons, to_ir
from testgen.renderer import render_to_docx

def _pick_questions(questions, num: Optional[int], seed: Optional[int], shuffle: bool = True):
    items = list(questions)
    rng = random.Random(seed)
    if shuffle:
        rng.shuffle(items)
    if num is not None and num > 0:
        items = items[:num]
        # reindexa para 1..N na saída (opcional, ajuda em prova)
        for i, q in enumerate(items, start=1):
            q.id = i
    return items

def jsons_to_docx(
    json_paths: List[str],
    template: str,
    out_docx: str,
    *,
    title: str = "Prova",
    placeholder: str = "{{QUESTOES}}",
    num: Optional[int] = None,
    seed: Optional[int] = None,    
    shuffle: bool = True,
) -> int:
    """
    Gera .docx a partir de N JSONs.
    - num: limitar quantidade de questões (embaralhadas)
    - seed: semente para embaralhamento (reprodutível)
    """
    raw = load_jsons(json_paths)
    quiz = to_ir(raw, title=title)
    quiz.questions = _pick_questions(quiz.questions, num=num, seed=seed, shuffle=shuffle)

    render_to_docx(quiz, template, out_docx, placeholder=placeholder)
    Path(out_docx).parent.mkdir(parents=True, exist_ok=True)
    return 0
