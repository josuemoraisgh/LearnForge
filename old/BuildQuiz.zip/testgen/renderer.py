# testgen/renderer.py
from docx import Document
from core.models import QuizIR, QuestionIR

def _letter(i: int) -> str:
    return chr(97 + i)  # a,b,c,...

def _question_plain(q: QuestionIR) -> str:
    lines = [f"{q.id}. {q.prompt}"]
    if q.choices:
        for i, c in enumerate(q.choices):
            lines.append(f"   {_letter(i)}) {c.text}")
    else:
        # TYPE4 fallback: pairs/answers em metadata
        meta = q.metadata or {}
        pairs = meta.get("pairs")
        if isinstance(pairs, list) and pairs:
            for i, p in enumerate(pairs):
                left = str(p[0])
                lines.append(f"   {_letter(i)}) {left}")
    return "\n".join(lines)

def render_to_docx(quiz: QuizIR, template_path: str, out_docx: str, placeholder="{{QUESTOES}}"):
    doc = Document(template_path)
    body_plain = "\n\n".join(_question_plain(q) for q in quiz.questions)
    for p in doc.paragraphs:
        if placeholder in p.text:
            p.text = p.text.replace(placeholder, body_plain)
    doc.save(out_docx)