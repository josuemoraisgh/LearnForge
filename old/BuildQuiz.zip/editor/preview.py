# editor/preview.py
# -*- coding: utf-8 -*-
"""
Preview textual simples para o Editor.
Entrada: lista de dicts normalizados pelo QuestionEditor._normalize_for_core()
Suporta type1, type2, type3, type4 (com 'pairs' ou 'afirmacoes') e imprime
alternativas com a) b) c). Se existir 'answer'/'answers' ou 'correta', a correta
já deve estar dentro das alternativas e será apenas indicada por (correta) no fim da linha.
"""

from typing import List, Dict, Any

ALPH = "abcdefghijklmnopqrstuvwxyz"

def _letter(i: int) -> str:
    return f"{ALPH[i%26]})"

def _roman(i: int) -> str:
    vals = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),
            (100,"C"),(90,"XC"),(50,"L"),(40,"XL"),
            (10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
    n=i+1; out=""
    for v,s in vals:
        while n>=v: out+=s; n-=v
    return out + ")"

def _norm_options(obj: Dict[str, Any]) -> List[str]:
    return list(obj.get("options") or obj.get("alternatives") or obj.get("alternativas") or [])

def _norm_correct(obj: Dict[str, Any], options: List[str]):
    # aceita 'answer' (número/letra/texto), 'answers' (lista), ou 'correta'
    # devolve um conjunto de índices corretos (0-based)
    idxs = set()
    def index_of(x):
        if isinstance(x, int):
            if 0 <= x < len(options): return x
            if 1 <= x <= len(options): return x-1
        if isinstance(x, str):
            s = x.strip()
            # letra
            if len(s)==1 and s.isalpha(): return ord(s.lower())-97
            # número
            if s.isdigit():
                k = int(s)
                return k-1 if 1<=k<=len(options) else k
            # texto (igual a alguma opção)
            for i, opt in enumerate(options):
                if s == str(opt).strip(): return i
        return -1

    if "answers" in obj and isinstance(obj["answers"], list):
        for a in obj["answers"]:
            k = index_of(a)
            if k >= 0: idxs.add(k)
    elif "answer" in obj:
        k = index_of(obj["answer"])
        if k >= 0: idxs.add(k)
    elif "correta" in obj:
        k = index_of(obj["correta"])
        if k >= 0: idxs.add(k)
    return idxs

def _render_type1(obj, i):
    enun = (obj.get("prompt") or "").strip()
    opts = _norm_options(obj)
    correct = _norm_correct(obj, opts)
    out = [f"{i}. {enun}"]
    for j, t in enumerate(opts):
        tag = " (correta)" if j in correct else ""
        out.append(f"   {_letter(j)} {t}{tag}")
    return "\n".join(out)

def _render_type2(obj, i):
    enun = (obj.get("prompt") or "").strip()
    # mostra V/F como alternativas também
    opts = ["Verdadeiro", "Falso"]
    correct = _norm_correct(obj, opts)
    out = [f"{i}. {enun}"]
    for j, t in enumerate(opts):
        tag = " (correta)" if j in correct else ""
        out.append(f"   {_letter(j)} {t}{tag}")
    return "\n".join(out)

def _render_type3(obj, i):
    enun = (obj.get("prompt") or "").strip()
    opts = _norm_options(obj)
    correct = _norm_correct(obj, opts)
    out = [f"{i}. {enun}"]
    for j, t in enumerate(opts):
        tag = " (correta)" if j in correct else ""
        out.append(f"   {_letter(j)} {t}{tag}")
    return "\n".join(out)

def _render_type4(obj, i):
    enun = (obj.get("prompt") or "").strip()
    out = [f"{i}. {enun}"]

    # afirmações: obj['pairs'] = [[chave, texto], ...] ou obj['afirmacoes'] = [[...], ...]
    pairs = obj.get("pairs")
    if not pairs and "afirmacoes" in obj:
        pairs = obj["afirmacoes"]
    if isinstance(pairs, dict):
        pairs = list(pairs.items())
    if isinstance(pairs, list):
        for k, v in pairs:
            # Ignoramos a chave do JSON e listamos como I), II), III)...
            # (a ordem do JSON é preservada pelo Python 3.7+)
            idx = pairs.index([k, v]) if [k, v] in pairs else 0  # robustez
        for j, it in enumerate(pairs):
            # it pode ser [k, v] ou {"k": "v"}
            if isinstance(it, (list, tuple)) and len(it) >= 2:
                txt = str(it[1])
            elif isinstance(it, dict):
                # pega primeiro par
                ((_, txt),) = list(it.items())[:1]
            else:
                txt = str(it)
            out.append(f"   {_roman(j)} {txt}")

    # alternativas da associação (ou resposta curta) — se houver
    opts = _norm_options(obj)
    correct = _norm_correct(obj, opts)
    for j, t in enumerate(opts):
        tag = " (correta)" if j in correct else ""
        out.append(f"   {_letter(j)} {t}{tag}")

    return "\n".join(out)

def preview_text(objs: List[Dict[str, Any]], title: str = "Pré-visualização") -> str:
    lines = [f"== {title} =="]
    for idx, o in enumerate(objs, start=1):
        t = (o.get("type") or "").lower()
        if t == "type1":
            lines.append(_render_type1(o, idx))
        elif t == "type2":
            lines.append(_render_type2(o, idx))
        elif t == "type3":
            lines.append(_render_type3(o, idx))
        elif t == "type4":
            lines.append(_render_type4(o, idx))
        else:
            # fallback: trata como multipla escolha
            lines.append(_render_type1(o, idx))
        lines.append("")  # linha em branco entre questões
    return "\n".join(lines).strip()