# beamer/generator.py
from pathlib import Path
from typing import List, Optional
import random

from core.parsers import load_jsons, to_ir
from beamer.renderer import render_quiz

def _shuffle_choices_only(quiz, seed: Optional[int]):
    """Embaralha APENAS as alternativas de cada questão (ordem das questões é preservada)."""
    if seed is None:
        return
    rng_global = random.Random(seed)
    for i, q in enumerate(quiz.questions, start=1):
        if q.choices:
            rng = random.Random((seed or 0) * 1000003 + i)
            shuffled = list(q.choices)
            rng.shuffle(shuffled)
            q.choices = shuffled
        # mantém q.id como veio do JSON (sem renumerar!)

def jsons_to_tex(
    json_paths: List[str],
    out_tex: str,
    *,
    title: str = "Slides",
    fsq: str = "Large",
    fsa: str = "normalsize",
    alert_color: str = "red",
    seed: Optional[int] = None,
) -> int:
    raw = load_jsons(json_paths)
    quiz = to_ir(raw, title=title)

    # **Importante**: NÃO embaralhar as questões no Beamer.
    # Opcional: embaralha só as alternativas (mantém correta misturada).
    _shuffle_choices_only(quiz, seed)

    tex = render_quiz(quiz, title=title, fsq=fsq, fsa=fsa, alert_color=alert_color)
    Path(out_tex).write_text(tex, encoding="utf-8")
    return 0

# Wrapper compatível com GUI antiga
def json2beamer(input_json, output_tex, shuffle_seed=None, title="Slides", fsq="Large", fsa="normalsize", alert_color="red"):
    paths = input_json if isinstance(input_json, (list, tuple)) else [input_json]
    return jsons_to_tex(paths, output_tex, title=title, fsq=fsq, fsa=fsa, alert_color=alert_color, seed=shuffle_seed)
