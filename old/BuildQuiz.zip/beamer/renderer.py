# beamer/renderer.py
from typing import Optional, List
from core.models import QuizIR, QuestionIR

def _latex_escape(s: str) -> str:
    if "\\" in (s or ""):
        return s or ""
    s = s or ""
    return (s.replace('\\', r'\textbackslash{}')
             .replace('&', r'\&').replace('%', r'\%')
             .replace('$', r'\$').replace('#', r'\#')
             .replace('_', r'\_').replace('{', r'\{')
             .replace('}', r'\}').replace('~', r'\textasciitilde{}')
             .replace('^', r'\textasciicircum{}'))

DEFAULT_PREAMBLE = (
    r"\documentclass[12pt]{beamer}" "\n"
    r"\usepackage{bookmark}" "\n"
    r"\usepackage[utf8]{inputenc}" "\n"
    r"\usepackage{amsmath}" "\n"
    r"\usepackage{amssymb}" "\n"
    r"\usetheme{Madrid}" "\n"
    r"\usepackage{graphicx}" "\n"
    r"\usepackage{enumitem}" "\n"
)
DEFAULT_POST = r"\end{document}" "\n"

def _alert_color_cmd(c: str) -> str:
    if not c: return ""
    c = c.strip()
    if c.startswith("#") and len(c) == 7:
        return (r"\usepackage{xcolor}" "\n"
                rf"\definecolor{{CustomAlert}}{{HTML}}{{{c[1:]}}}" "\n"
                r"\setbeamercolor{alerted text}{fg=CustomAlert}" "\n")
    return (r"\usepackage{xcolor}" "\n"
            rf"\setbeamercolor{{alerted text}}{{fg={c}}}" "\n")

def _frame_title(q: QuestionIR) -> str:
    return f"{q.id}. {_latex_escape(q.prompt or '')}"

def _letter(i: int) -> str:      # a), b), c)...
    return chr(97 + i) + ")"

def _roman(i: int) -> str:       # I), II), III)...
    vals = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),
            (100,"C"),(90,"XC"),(50,"L"),(40,"XL"),
            (10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
    n=i+1; out=""
    for v,s in vals:
        while n>=v: out+=s; n-=v
    return out + ")"

def _render_images(q: QuestionIR) -> List[str]:
    out: List[str] = []
    for a in (q.assets or []):
        if getattr(a, "kind", "") == "image" and a.src:
            src = _latex_escape(a.src)
            out += [r"\begin{center}", rf"\includegraphics[width=0.85\linewidth]{{{src}}}", r"\end{center}"]
    return out

def _render_afirmacoes(q: QuestionIR) -> List[str]:
    af = (q.metadata or {}).get("afirmacoes", [])
    if not af: return []
    # af: List[(chave, texto)]  — ignoramos a chave e numeramos como I), II)...
    lines = [r"\begin{itemize}[leftmargin=*]"]
    for i, (_, txt) in enumerate(af):
        lines.append(rf"\item { _roman(i) } {_latex_escape(txt or '')}")
    lines.append(r"\end{itemize}")
    return lines

def _render_choices(q: QuestionIR, show_answer: bool, fsa: str) -> List[str]:
    if not q.choices: return []
    lines: List[str] = [r"\begin{itemize}[leftmargin=*]"]
    for i, ch in enumerate(q.choices):
        txt = _latex_escape(ch.text or "").strip()
        if not txt: continue
        lab = _letter(i) + " "
        if show_answer and ch.is_correct:
            txt = rf"\alert{{{txt}}}"
        lines.append(rf"\item {{\{fsa} {lab}{txt}}}")
    lines.append(r"\end{itemize}")
    return lines

def _frame_question(q: QuestionIR, show_answer: bool, fsq: str, fsa: str) -> str:
    lines: List[str] = [r"\begin{frame}", rf"\frametitle{{{_frame_title(q)}}}", r"{\BodySize"]
    # imagens
    lines += _render_images(q)
    # se for type4, mostra Afirmações (I, II, III…) antes das alternativas
    if str(q.kind).endswith("TYPE4"):
        lines += _render_afirmacoes(q)
    # alternativas (a,b,c…) com/sem alert
    lines += _render_choices(q, show_answer=show_answer, fsa=fsa)
    lines.append("}")
    lines.append(r"\end{frame}")
    return "\n".join(lines) + "\n"

def _frame_obs(q: QuestionIR, fsa: str) -> str:
    raw = (q.metadata or {}).get("obs")
    if isinstance(raw, str):
        items = [raw.strip()] if raw.strip() else []
    elif isinstance(raw, list):
        items = [str(x).strip() for x in raw if str(x).strip()]
    else:
        items = []
    if not items: return ""
    lines = [r"\begin{frame}", rf"\frametitle{{{_frame_title(q)}}}", r"{\BodySize"]
    lines.append(r"{\bfseries OBS.:}")
    lines.append(r"\begin{itemize}")
    for it in items:
        lines.append(r"\item " + _latex_escape(it))
    lines.append(r"\end{itemize}")
    lines.append("}")
    lines.append(r"\end{frame}")
    return "\n".join(lines) + "\n"

def render_quiz(quiz: QuizIR, title="Exercícios – Apresentação", fsq="Large", fsa="normalsize",
                *, preamble: Optional[str]=None, post: Optional[str]=None, alert_color="red") -> str:
    preamble = (preamble if preamble is not None else DEFAULT_PREAMBLE) + _alert_color_cmd(alert_color)
    post = post if post is not None else DEFAULT_POST
    parts: List[str] = [
        preamble,
        rf"\title{{{_latex_escape(quiz.title or title)}}}",
        r"\author{}", r"\date{}",
        r"\begin{document}",
        r"\frame{\titlepage}",
        rf"\setbeamerfont{{frametitle}}{{size=\{fsq}}}",
        rf"\newcommand{{\BodySize}}{{\{fsa}}}",
    ]
    for q in quiz.questions:
        parts.append(_frame_question(q, show_answer=False, fsq=fsq, fsa=fsa))
        parts.append(_frame_question(q, show_answer=True,  fsq=fsq, fsa=fsa))  # correta em \alert
        obs = _frame_obs(q, fsa=fsa)
        if obs:
            parts.append(obs)
    parts.append(post)
    return "\n".join(parts)
