# core/loader.py
from __future__ import annotations
from typing import List, Dict, Any
from .models import Question

def _normalize_alternativas_key(q: Dict[str, Any]) -> Dict[str, Any]:
    """
    Aceita 'alternativas' e 'alternativas;K'.
    - Se houver 'alternativas;K' e 'alternativas' estiver AUSENTE ou VAZIA,
      move a LISTA INTEIRA de 'alternativas;K' para q['alternativas'].
    - Guarda K como metadado em q['_firstrow'] (para Beamer).
    - Remove TODAS as chaves 'alternativas;K' após normalizar (evita sobrescrita posterior).
    """
    # Fonte padrão (pode vir ausente ou vazia)
    alts_std = q.get("alternativas")

    # Encontre TODAS as chaves alternativas;K
    altk_entries: List[tuple[str, int|None]] = []
    for k in list(q.keys()):
        if isinstance(k, str) and k.startswith("alternativas;"):
            # tenta extrair K
            K = None
            try:
                K = int(k.split(";", 1)[1])
            except Exception:
                K = None
            altk_entries.append((k, K))

    if altk_entries:
        # Só precisamos de UM K (se houver mais de um, fica o primeiro válido)
        for _, K in altk_entries:
            if K is not None:
                q["_firstrow"] = K
                break

        # Se 'alternativas' não existe, não é lista ou é lista vazia, substitui pela LISTA de 'alternativas;K' (primeira encontrada que seja lista)
        need_replace = (not isinstance(alts_std, list)) or (len(alts_std) == 0)
        if need_replace:
            for key, _K in altk_entries:
                v = q.get(key)
                if isinstance(v, list):
                    q["alternativas"] = list(v)   # COPIA A LISTA INTEIRA
                    break
            else:
                # nenhuma era lista: normaliza para lista vazia/escalares
                for key, _K in altk_entries:
                    v = q.get(key)
                    if v is None:
                        q["alternativas"] = []
                    else:
                        q["alternativas"] = [v]
                    break

        # REMOVER TODAS as chaves 'alternativas;K' para impedir que etapas posteriores sobrescrevam 'alternativas'
        for key, _ in altk_entries:
            q.pop(key, None)

    return q


def _normalize_alternativas_on_raw(raw: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Aplica a normalização em todas as questões cruas (dicts) lidas do JSON."""
    return [_normalize_alternativas_key(dict(q)) for q in raw]


def normalize_ids(questions: List[Question]) -> None:
    """Renumera sequencialmente se você quiser forçar IDs 1..N."""
    questions.sort(key=lambda q: q.id or 0)
    for i, q in enumerate(questions, start=1):
        q.id = i


def load_questions(raw: List[Dict[str, Any]], renumber_ids: bool = False) -> List[Question]:
    """
    Carrega questões a partir de dicts (raw) vindos do JSON.

    Passos:
    1) Normaliza 'alternativas;K' -> 'alternativas' + metadado '_firstrow' e REMOVE 'alternativas;K'.
    2) Constrói Question.from_dict(...).
    3) (Opcional) renumera IDs.
    4) Validações leves.
    """
    # 1) NORMALIZAR (em dict), ANTES de instanciar Question
    raw = _normalize_alternativas_on_raw(raw)

    # 2) Agora sim, criar os objetos
    qs = [Question.from_dict(x) for x in raw]

    # 3) Opcionalmente, renumerar
    if renumber_ids:
        normalize_ids(qs)

    # 4) Validações (ajuste conforme seu modelo)
    for q in qs:
        if not q.dificuldade:
            q.dificuldade = "média"
        if not isinstance(q.alternativas, list):
            q.alternativas = []
        if not isinstance(q.imagens, list):
            q.imagens = []
        if q.tipo.value == 3:
            if not q.variaveis or not q.resolucoes:
                raise ValueError(f"Questão {q.id}: Tipo 3 requer 'variaveis' e 'resolucoes'.")
        if q.tipo.value == 4 and not q.afirmacoes:
            raise ValueError(f"Questão {q.id}: Tipo 4 requer 'afirmacoes'.")
        if not (q.enunciado or "").strip():
            raise ValueError(f"Questão {q.id}: 'enunciado' não pode ser vazio.")

    return qs